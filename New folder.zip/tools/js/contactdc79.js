function contactUs() {
    var name = $("#tf_name").val();
    var mobile = $("#tf_mobile").val();
    var email = $("#tf_email").val();
    var msg = $("#tf_msg").val();
    var mobExp = /^[7,8,9]{1}[0-9]{9}$/;

    if (name == "") {
            toast(0, "Please enter your name.");
            return false;
    } 
    else if (mobile === "" || $.trim(mobile).length !== 10 || !mobile.match(mobExp)) {
            toast(0, "Please enter a valid mobile number.");
            return false;
    }
    else if (email === "") {
            toast(0, "Please enter your email address.");
            return false;
    }
    else if (validateEmail(email)) {
            toast(0, "Please enter valid email address.");
            return false;
    }
    else if (msg == "") {
            toast(0, "Please enter your message");
            return false;
    }

    name=encodeURIComponent(name);
    var em=encodeURIComponent(email);
    msg=encodeURIComponent(msg);

    var url = 'contact.php';
    var params = 'name='+name+'&em='+em+'&mobile='+mobile+'&msg='+msg;

    $.ajax({
            url: url,
            dataType: 'json',
            type: 'POST',
            data: params,
            success: function(data) {
                    if(data !== undefined)
                    {
                            if(data.errC !== undefined && data.errM !== undefined)
                            {
                                    toast(0, data.errM);
                            }
                    }
                    else
                    {
                            toast(0, 'Error sending message!');
                    }

                    setTimeout(function () {
                           // window.location.reload();
                    }, 2000);
            }
    });
}

function toast(mType, msg) {
    $('.close').click();
    $.toast.config.width = 400;
    $.toast.config.closeForStickyOnly = false;
    if (mType == 0) {
        $.toast(msg, {duration: 5000, type: "danger"});
    } else if (mType == 1) {
        $.toast(msg, {duration: 5000, type: "success"});
    }
    setTimeout(function(){
        $('.close').click();
    },5000);
}


function validateEmail (email) {
        var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
        if (!email.match(mailformat)) {
            return 1;
        }
        return 0;
    };
    
    
function isNumberKey(evt){
    var charCode = (evt.which) ? evt.which : event.keyCode
    if (charCode > 31 && (charCode < 48 || charCode > 57))
    return false;
    return true;
}